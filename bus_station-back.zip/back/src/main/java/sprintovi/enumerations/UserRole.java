package sprintovi.enumerations;

public enum UserRole {
    ADMIN,
    KORISNIK
}
