package sprintovi.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Driver {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull
	@NotBlank
	@Column(unique = true)
	private String name;
	
	@Column
	private String address;
	
	@NotNull
	@NotBlank
	@Column(unique = true)
	private String pib;
	
	@OneToMany(mappedBy = "driver")
	private List<Line> lines;

	public Driver() {
		super();
	}

	public Driver(Long id, @NotNull @NotBlank String name, String address, @NotNull @NotBlank String pib,
			List<Line> lines) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.pib = pib;
		this.lines = lines;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPib() {
		return pib;
	}

	public void setPib(String pib) {
		this.pib = pib;
	}

	public List<Line> getLines() {
		return lines;
	}

	public void setLines(List<Line> lines) {
		this.lines = lines;
	}
	
	
	
	

}
