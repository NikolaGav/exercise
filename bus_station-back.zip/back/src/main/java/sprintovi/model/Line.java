package sprintovi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Entity
	public class Line {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotNull
	@Column
	private Integer numberOfSeat;
	
	@Column
	private Double price;
	
	@Column
	private String timeOfDeparture;
	
	@NotNull
	@Column
	private String destination;
	
	@ManyToOne
	private Driver driver;

	public Line() {
		super();
	}

	public Line(Long id, @NotNull Integer numberOfSeat, Double price, String timeOfDeparture,
			@NotNull String destination, Driver driver) {
		super();
		this.id = id;
		this.numberOfSeat = numberOfSeat;
		this.price = price;
		this.timeOfDeparture = timeOfDeparture;
		this.destination = destination;
		this.driver = driver;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getNumberOfSeat() {
		return numberOfSeat;
	}

	public void setNumberOfSeat(Integer numberOfSeat) {
		this.numberOfSeat = numberOfSeat;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getTimeOfDeparture() {
		return timeOfDeparture;
	}

	public void setTimeOfDeparture(String timeOfDeparture) {
		this.timeOfDeparture = timeOfDeparture;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}
	
	
	
	
	

}
