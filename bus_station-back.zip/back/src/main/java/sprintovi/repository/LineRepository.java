package sprintovi.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import sprintovi.model.Line;

@Repository
public interface LineRepository extends JpaRepository<Line, Long> {

	Line findOneById(Long id);

	Page<Line> findByPriceLessThanEqualAndDestinationIgnoreCaseContains(Double maxPrice, String destination,
			PageRequest of);

	Page<Line> findByDestinationIgnoreCaseContainsAndPriceLessThanEqualAndDriverId(String destination, Double maxPrice,
			Long idDriver, PageRequest of);


	
	
	
	

}
