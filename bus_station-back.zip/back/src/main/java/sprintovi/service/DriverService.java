package sprintovi.service;

import java.util.List;

import sprintovi.model.Driver;

public interface DriverService {
	
	List<Driver> findAll();
	
	Driver findOneById(Long id);
	
	Driver save(Driver driver);

	
	
	
	
}
