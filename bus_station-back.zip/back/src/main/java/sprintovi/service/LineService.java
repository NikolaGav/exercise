package sprintovi.service;

import org.springframework.data.domain.Page;

import sprintovi.model.Line;

public interface LineService {
	
	
	Line findOneById(Long id);
	
	Line save (Line line);
	
	void delete(Line line);
	
	
	Page<Line> findSearch(String destination, Long idDriver, Double maxPrice, Integer pageNo);
	

}
