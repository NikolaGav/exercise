package sprintovi.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sprintovi.model.Driver;
import sprintovi.repository.DriverRepository;
import sprintovi.service.DriverService;

@Service
public class JpaDriverService implements DriverService {
	
	@Autowired
	private DriverRepository driverRepository;
	

	@Override
	public List<Driver> findAll() {
		return driverRepository.findAll();
	}

	@Override
	public Driver findOneById(Long id) {
		return driverRepository.findOneById(id);
	}

	@Override
	public Driver save(Driver driver) {
		return driverRepository.save(driver);
	}

}
