package sprintovi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import sprintovi.model.Line;
import sprintovi.repository.LineRepository;
import sprintovi.service.LineService;

@Service
public class JpaLineService implements LineService {
	
	@Autowired
	private LineRepository lineRepository;

	@Override
	public Line findOneById(Long id) {
		
		return lineRepository.findOneById(id);
	}

	@Override
	public Line save(Line line) {
		return lineRepository.save(line);
	}

	@Override
	public void delete(Line line) {
		lineRepository.delete(line);
		
	}

	@Override
	public Page<Line> findSearch(String destination, Long idDriver, Double maxPrice, Integer pageNo) {
		
		if(maxPrice == null) {
			maxPrice = Double.MAX_VALUE;
		}
		
		if(destination == null) {
			destination = "";
		}
		
		if(idDriver == null) {
			return lineRepository.findByPriceLessThanEqualAndDestinationIgnoreCaseContains(maxPrice, destination, PageRequest.of(pageNo, 2));
		}
		
		return lineRepository.findByDestinationIgnoreCaseContainsAndPriceLessThanEqualAndDriverId(destination, maxPrice, idDriver, PageRequest.of(pageNo, 2));
	}

}
