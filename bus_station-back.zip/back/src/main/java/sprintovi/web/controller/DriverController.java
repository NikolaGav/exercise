package sprintovi.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.Driver;
import sprintovi.service.DriverService;
import sprintovi.web.dto.DriverDTO;
import sprintovi.web.dto.DriverDtoToDriver;
import sprintovi.web.dto.DriverToDriverDto;

@RestController
@RequestMapping(value = "/api/drivers", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
public class DriverController {

	@Autowired
	private DriverService driverService;

	@Autowired
	private DriverToDriverDto toDriverDto;

	@Autowired
	private DriverDtoToDriver toDriver;


	@GetMapping
	public ResponseEntity<List<DriverDTO>> getAll() {

		List<Driver> drivers = driverService.findAll();

		return new ResponseEntity<List<DriverDTO>>(toDriverDto.convert(drivers), HttpStatus.OK);

	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DriverDTO> create(@Valid @RequestBody DriverDTO driverDTO) {

		Driver saveDriver = driverService.save(toDriver.convert(driverDTO));

		return new ResponseEntity<DriverDTO>(toDriverDto.convert(saveDriver), HttpStatus.CREATED);

	}





}



















