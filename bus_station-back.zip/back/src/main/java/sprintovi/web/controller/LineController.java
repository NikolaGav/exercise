package sprintovi.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import sprintovi.model.Line;
import sprintovi.service.LineService;
import sprintovi.web.dto.LineDTO;
import sprintovi.web.dto.LineDtoToLine;
import sprintovi.web.dto.LineToLineDto;

@RestController
@RequestMapping(value = "/api/lines", produces = MediaType.APPLICATION_JSON_VALUE)
@Validated
public class LineController {
	
	@Autowired
	private LineService lineService;
	
	
	@Autowired
	private LineToLineDto toLineDto;
	
	@Autowired
	private LineDtoToLine toLine;
	
	
	
	@GetMapping
	public ResponseEntity<List<LineDTO>> getAll(
			@RequestParam(required = false) String destination,
			@RequestParam(required = false) Long idDriver,
			@RequestParam(required = false) Double maxPrice,
			@RequestParam(required = false, defaultValue = "0") Integer pageNo 
			) {
		
		Page<Line> dtoLine = lineService.findSearch(destination, idDriver, maxPrice, pageNo);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("total-Pages", Integer.toString(dtoLine.getTotalPages()));
		
		
		return new ResponseEntity<List<LineDTO>>(toLineDto.convert(dtoLine.getContent()), headers, HttpStatus.OK);
	}
	
	
	
	
	
	@GetMapping("/{id}")
	public ResponseEntity<LineDTO> getOne(@PathVariable Long id) {
		
		Line line = lineService.findOneById(id);
		
		if(line == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<>(toLineDto.convert(line), HttpStatus.OK);
		}
		
	}
	
	
	@GetMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LineDTO> create(@RequestBody LineDTO lineDTO) {
		
		Line saveLine = lineService.save(toLine.convert(lineDTO));
		
		return new ResponseEntity<>(toLineDto.convert(saveLine), HttpStatus.CREATED);
	}
	
	
	@PostMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LineDTO> update(@PathVariable Long id, @RequestBody LineDTO lineDTO) {
		
		if(id != lineDTO.getId()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			Line line = lineService.save(toLine.convert(lineDTO));
			
			return new ResponseEntity<>(toLineDto.convert(line), HttpStatus.ACCEPTED);
		}
		
	}
	
	
	@DeleteMapping(value = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		
		if( lineService.findOneById(id) != null) {
			lineService.delete(lineService.findOneById(id));
			return new ResponseEntity<Void>(HttpStatus.OK);
		} else {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		
		
	}
	
	
	
	

}






























