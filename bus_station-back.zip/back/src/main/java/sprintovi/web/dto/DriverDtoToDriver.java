package sprintovi.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Driver;
import sprintovi.service.DriverService;

@Component
public class DriverDtoToDriver implements Converter<DriverDTO, Driver> {
	
	@Autowired
	private DriverService driverService;

	@Override
	public Driver convert(DriverDTO source) {
		Driver driver;
		
		if(source.getId() == null)	{
			driver = new Driver();
		} else {
			driver = driverService.findOneById(source.getId());
		}
		
		
		driver.setAddress(source.getAddress());
		driver.setName(source.getName());
		driver.setPib(source.getPib());
		
		return driver;
	}

}
