package sprintovi.web.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Driver;

@Component
public class DriverToDriverDto implements Converter<Driver, DriverDTO> {
	
	

	@Override
	public DriverDTO convert(Driver source) {
		
		DriverDTO driverDTO = new DriverDTO();
		
		driverDTO.setId(source.getId());
		driverDTO.setAddress(source.getAddress());
		driverDTO.setName(source.getName());
		driverDTO.setPib(source.getPib());
		
		
		return driverDTO;
	}
	
	
	public List<DriverDTO> convert(List<Driver> drivers) {
		
		List<DriverDTO> driverDTOs = new ArrayList<>();
		
		for(Driver itDriver : drivers) {
			driverDTOs.add(convert(itDriver));
		}
		
		return driverDTOs;
		
		
	}
	

}
