package sprintovi.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Line;
import sprintovi.service.DriverService;
import sprintovi.service.LineService;

@Component
public class LineDtoToLine implements Converter<LineDTO, Line> {
	
	@Autowired
	private LineService lineService;
	
	@Autowired
	private DriverService driverService;

	
	
	@Override
	public Line convert(LineDTO source) {
		
		Line line;
		
		if(source.getId() == null) {
			line = new Line();
		} else {
			line = lineService.findOneById(source.getId());
		}
		
		line.setNumberOfSeat(source.getNumberOfSeat());
		line.setPrice(source.getPrice());
		line.setDriver(driverService.findOneById(source.getDriverId()));
		line.setTimeOfDeparture(source.getTimeOfDeparture());
		line.setDestination(source.getDestination());
		
		
		return line;
	}

}
