package sprintovi.web.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import sprintovi.model.Line;

@Component
public class LineToLineDto implements Converter<Line, LineDTO> {
		

	@Override
	public LineDTO convert(Line source) {
		
		LineDTO dto = new LineDTO();
		
		dto.setId(source.getId());
		dto.setNumberOfSeat(source.getNumberOfSeat());
		dto.setDestination(source.getDestination());
		dto.setPrice(source.getPrice());
		dto.setTimeOfDeparture(source.getTimeOfDeparture());
		dto.setDriverId(source.getDriver().getId());
		dto.setDriverName(source.getDriver().getName());
		
		
		return dto;
	}
	
	
	public List<LineDTO> convert(List<Line> lines) {
		
		List<LineDTO> lineDTOs = new ArrayList<>();
		
		for(Line itLine : lines) {
			lineDTOs.add(convert(itLine));
		}
		
		
		return lineDTOs;
	}

}
