INSERT INTO `user` (id, username, password, role)
              VALUES (1,'miroslav','$2y$12$NH2KM2BJaBl.ik90Z1YqAOjoPgSd0ns/bF.7WedMxZ54OhWQNNnh6','ADMIN');
INSERT INTO `user` (id, username, password, role)
              VALUES (2,'tamara','$2y$12$DRhCpltZygkA7EZ2WeWIbewWBjLE0KYiUO.tHDUaJNMpsHxXEw9Ky','KORISNIK');
INSERT INTO `user` (id, username, password, role)
              VALUES (3,'petar','$2y$12$i6/mU4w0HhG8RQRXHjNCa.tG2OwGSVXb0GYUnf8MZUdeadE4voHbC','KORISNIK');
              
              

INSERT INTO driver (id, address, name, pib)
              VALUES (1, 'Via Beograd 1', 'Nikola 1', 'Pib 1');
INSERT INTO driver (id, address, name, pib)
              VALUES (2, 'Via Beograd 2', 'Nikola 2', 'Pib 2');
INSERT INTO driver (id, address, name, pib)
              VALUES (3, 'Via Beograd 3', 'Nikola 3', 'Pib 3');
              
              
INSERT INTO line (id, destination, number_of_seat, price, time_of_departure, driver_id)
              VALUES (1, 'Beograd', 50, 1000, '15:00', 1);
INSERT INTO line (id, destination, number_of_seat, price, time_of_departure, driver_id)
              VALUES (2, 'Novi Sad', 30, 500, '12:00', 2);
INSERT INTO line (id, destination, number_of_seat, price, time_of_departure, driver_id)
              VALUES (3, 'Beograd', 50, 1000, '15:00', 3);
